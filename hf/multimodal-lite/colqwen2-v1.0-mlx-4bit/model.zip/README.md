---
library_name: transformers
tags:
- colpali
- mlx
license: apache-2.0
datasets:
- vidore/colpali_train_set
language:
- en
base_model:
- vidore/colqwen2-base
pipeline_tag: visual-document-retrieval
---

# thoddnn/colqwen2-v1.0-mlx-4bit

The Model [thoddnn/colqwen2-v1.0-mlx-4bit](https://huggingface.co/thoddnn/colqwen2-v1.0-mlx-4bit) was converted to MLX format from [vidore/colqwen2-v1.0-hf](https://huggingface.co/vidore/colqwen2-v1.0-hf) using mlx-lm version **0.0.3**.

## Use with mlx

```bash
pip install mlx-embeddings
```

```python
from mlx_embeddings import load, generate
import mlx.core as mx

model, tokenizer = load("thoddnn/colqwen2-v1.0-mlx-4bit")

# For text embeddings
output = generate(model, processor, texts=["I like grapes", "I like fruits"])
embeddings = output.text_embeds  # Normalized embeddings

# Compute dot product between normalized embeddings
similarity_matrix = mx.matmul(embeddings, embeddings.T)

print("Similarity matrix between texts:")
print(similarity_matrix)


```
