---
language:
- en
license: other
license_name: tongyi-qianwen-research
license_link: LICENSE
pipeline_tag: image-text-to-text
tags:
- vision
- image-text-to-text
- mlx
---

# mlx-community/llava-interleave-qwen-7b-bf16
This model was converted to MLX format from [`llava-hf/llava-interleave-qwen-7b-hf`]() using mlx-vlm version **0.1.21**.
Refer to the [original model card](https://huggingface.co/llava-hf/llava-interleave-qwen-7b-hf) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/llava-interleave-qwen-7b-bf16 --max-tokens 100 --temperature 0.0 --prompt "Describe this image." --image <path_to_image>
```
