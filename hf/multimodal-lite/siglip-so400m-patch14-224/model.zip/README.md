---
license: apache-2.0
tags:
- vision
- mlx
widget:
- src: https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/bee.jpg
  candidate_labels: bee in the sky, bee on the flower
  example_title: Bee
library_name: transformers
pipeline_tag: zero-shot-image-classification
---

# mlx-community/siglip-so400m-patch14-224

The Model [mlx-community/siglip-so400m-patch14-224](https://huggingface.co/mlx-community/siglip-so400m-patch14-224) was converted to MLX format from [google/siglip-so400m-patch14-224](https://huggingface.co/google/siglip-so400m-patch14-224) using mlx-lm version **0.0.2**.

## Use with mlx

```bash
pip install mlx-lm
```

```python
from mlx_lm import load, generate

model, tokenizer = load("mlx-community/siglip-so400m-patch14-224")
response = generate(model, tokenizer, prompt="hello", verbose=True)
```
