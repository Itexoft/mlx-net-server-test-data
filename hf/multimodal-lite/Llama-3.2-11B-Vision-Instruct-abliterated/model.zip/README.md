---
language:
- en
- de
- fr
- it
- pt
- hi
- es
- th
library_name: transformers
license: llama3.2
pipeline_tag: image-text-to-text
base_model: meta-llama/Llama-3.2-11B-Vision-Instruct
tags:
- facebook
- meta
- pytorch
- llama
- llama-3
- abliterated
- uncensored
- mlx
---

# mlx-community/Llama-3.2-11B-Vision-Instruct-abliterated
This model was converted to MLX format from [`huihui-ai/Llama-3.2-11B-Vision-Instruct-abliterated`]() using mlx-vlm version **0.1.4**.
Refer to the [original model card](https://huggingface.co/huihui-ai/Llama-3.2-11B-Vision-Instruct-abliterated) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/Llama-3.2-11B-Vision-Instruct-abliterated --max-tokens 100 --temp 0.0
```
