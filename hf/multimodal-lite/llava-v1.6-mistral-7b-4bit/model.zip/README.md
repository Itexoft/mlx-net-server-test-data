---
license: apache-2.0
tags:
- vision
- image-text-to-text
- mlx
---

# mlx-community/llava-v1.6-mistral-7b-4bit
This model was converted to MLX format from [`llava-hf/llava-v1.6-mistral-7b-hf`]() using mlx-vlm version **0.0.9**.
Refer to the [original model card](https://huggingface.co/llava-hf/llava-v1.6-mistral-7b-hf) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/llava-v1.6-mistral-7b-4bit --max-tokens 100 --temp 0.0
```
