---
license: apple-amlr
pipeline_tag: image-text-to-text
tags:
- mlx
---

# mlx-community/FastVLM-0.5B-bf16
This model was converted to MLX format from [`apple/FastVLM-0.5B`](https://huggingface.co/apple/FastVLM-0.5B) using mlx-vlm from [this PR](https://github.com/Blaizzy/mlx-vlm/pull/502).
Refer to the [original model card](https://huggingface.co/apple/FastVLM-0.5B) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/FastVLM-0.5B-bf16 --max-tokens 100 --temperature 0.0 --prompt "Describe this image in detail." --image https://huggingface.co/datasets/huggingface/documentation-images/resolve/0052a70beed5bf71b92610a43a52df6d286cd5f3/diffusers/rabbit.jpg
```