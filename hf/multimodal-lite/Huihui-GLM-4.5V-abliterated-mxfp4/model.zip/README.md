---
language:
- zh
- en
library_name: mlx
license: mit
pipeline_tag: image-text-to-text
base_model:
- zai-org/GLM-4.5V
tags:
- abliterated
- uncensored
- mlx
---

# mlx-community/Huihui-GLM-4.5V-abliterated-mxfp4
This model was converted to MLX format from [`huihui-ai/Huihui-GLM-4.5V-abliterated`]() using [`mlx-vlm` with MXFP4 support](https://github.com/zhutao100/mlx-vlm.git).  
Refer to the [original model card](https://huggingface.co/huihui-ai/Huihui-GLM-4.5V-abliterated) for more details on the model.
## Use with mlx

```bash
pip install git+https://github.com/zhutao100/mlx-vlm.git
```

```bash
python -m mlx_vlm.generate --model mlx-community/Huihui-GLM-4.5V-abliterated-mxfp4 --max-tokens 100 --temperature 0.0 --prompt "Describe this image." --image <path_to_image>
```
