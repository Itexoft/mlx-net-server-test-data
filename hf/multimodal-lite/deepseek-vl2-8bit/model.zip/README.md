---
license: other
license_name: deepseek
license_link: https://github.com/deepseek-ai/DeepSeek-LLM/blob/HEAD/LICENSE-MODEL
pipeline_tag: image-text-to-text
library_name: transformers
tags:
- mlx
---

# mlx-community/deepseek-vl2-8bit
This model was converted to MLX format from [`prince-canuma/deepseek-vl2`]() using mlx-vlm version **0.1.9**.
Refer to the [original model card](https://huggingface.co/prince-canuma/deepseek-vl2) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/deepseek-vl2-8bit --max-tokens 100 --temp 0.0
```
