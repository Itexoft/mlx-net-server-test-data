---
license: apache-2.0
pipeline_tag: image-text-to-text
library_name: transformers
base_model:
- OpenGVLab/InternVL3_5-30B-A3B-MPO
base_model_relation: finetune
datasets:
- OpenGVLab/MMPR-v1.2
- OpenGVLab/MMPR-Tiny
language:
- multilingual
tags:
- internvl
- custom_code
- mlx
---

# mlx-community/InternVL3_5-30B-A3B-4bit
This model was converted to MLX format from [`OpenGVLab/InternVL3_5-30B-A3B-HF`]() using mlx-vlm version **0.3.3**.
Refer to the [original model card](https://huggingface.co/OpenGVLab/InternVL3_5-30B-A3B-HF) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/InternVL3_5-30B-A3B-4bit --max-tokens 100 --temperature 0.0 --prompt "Describe this image." --image <path_to_image>
```
