---
license: apache-2.0
datasets:
- HuggingFaceM4/OBELICS
- HuggingFaceM4/the_cauldron
- HuggingFaceM4/Docmatix
- HuggingFaceM4/WebSight
language:
- en
tags:
- multimodal
- vision
- image-text-to-text
- mlx
library_name: transformers
---

# mlx-community/Idefics3-8B-Llama3-8bit
This model was converted to MLX format from [`HuggingFaceM4/Idefics3-8B-Llama3`]() using mlx-vlm version **0.1.12**.
Refer to the [original model card](https://huggingface.co/HuggingFaceM4/Idefics3-8B-Llama3) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/Idefics3-8B-Llama3-8bit --max-tokens 100 --temp 0.0 --prompt "Describe this image." --image <path_to_image>
```
