---
license: apache-2.0
tags:
- mlx
---

# thoddnn/colqwen2.5-v0.2-mlx-8bit-test

The Model [thoddnn/colqwen2.5-v0.2-mlx-8bit-test](https://huggingface.co/thoddnn/colqwen2.5-v0.2-mlx-8bit-test) was converted to MLX format from [thoddnn/colqwen2.5-v0.2-mlx](https://huggingface.co/thoddnn/colqwen2.5-v0.2-mlx) using mlx-lm version **0.0.3**.

## Use with mlx

```bash
pip install mlx-embeddings
```

```python
from mlx_embeddings import load, generate
import mlx.core as mx

model, tokenizer = load("thoddnn/colqwen2.5-v0.2-mlx-8bit-test")

# For text embeddings
output = generate(model, processor, texts=["I like grapes", "I like fruits"])
embeddings = output.text_embeds  # Normalized embeddings

# Compute dot product between normalized embeddings
similarity_matrix = mx.matmul(embeddings, embeddings.T)

print("Similarity matrix between texts:")
print(similarity_matrix)


```
