---
license: mit
pipeline_tag: text-generation
library_name: transformers
tags:
- mlx
---

# mlx-community/Apriel-1.5-15b-Thinker-4bit
This model was converted to MLX format from [`ServiceNow-AI/Apriel-1.5-15b-Thinker`]() using mlx-vlm version **0.3.3**.
Refer to the [original model card](https://huggingface.co/ServiceNow-AI/Apriel-1.5-15b-Thinker) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/Apriel-1.5-15b-Thinker-4bit --max-tokens 100 --temperature 0.0 --prompt "Describe this image." --image <path_to_image>
```
