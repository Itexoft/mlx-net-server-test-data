---
inference: false
library_name: transformers
language:
- en
- fr
- de
- es
- it
- pt
license: cc-by-nc-4.0
extra_gated_prompt: By submitting this form, you agree to the [License Agreement](https://cohere.com/c4ai-cc-by-nc-license)  and
  acknowledge that the information you provide will be collected, used, and shared
  in accordance with Cohere’s [Privacy Policy]( https://cohere.com/privacy). You’ll
  receive email updates about C4AI and Cohere research, events, products and services.
  You can unsubscribe at any time.
extra_gated_fields:
  Name: text
  Affiliation: text
  Country: country
  I agree to use this model for non-commercial use ONLY: checkbox
pipeline_tag: image-text-to-text
base_model:
- CohereLabs/c4ai-command-a-03-2025
- google/siglip2-so400m-patch16-512
tags:
- mlx
---

# mlx-community/command-a-vision-07-2025-4bit
This model was converted to MLX format from [`CohereLabs/command-a-vision-07-2025`]() using mlx-vlm version **0.3.3**.
Refer to the [original model card](https://huggingface.co/CohereLabs/command-a-vision-07-2025) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/command-a-vision-07-2025-4bit --max-tokens 100 --temperature 0.0 --prompt "Describe this image." --image <path_to_image>
```
