---
license: mit
license_link: https://huggingface.co/microsoft/Florence-2-large-ft/resolve/main/LICENSE
pipeline_tag: image-text-to-text
tags:
- vision
- mlx
---

# mlx-community/Florence-2-large-ft-bf16
This model was converted to MLX format from [`prince-canuma/Florence-2-large-ft`]() using mlx-vlm version **0.1.0**.
Refer to the [original model card](https://huggingface.co/prince-canuma/Florence-2-large-ft) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/Florence-2-large-ft-bf16 --max-tokens 100 --temp 0.0
```
