---
license: apache-2.0
library_name: mlx
tags:
- mlx
base_model:
- google/siglip2-base-patch16-224
---

# mlx-community/siglip2-base-patch16-224-8bit

This model [mlx-community/siglip2-base-patch16-224-8bit](https://huggingface.co/mlx-community/siglip2-base-patch16-224-8bit) was
converted to MLX format from [google/siglip2-base-patch16-224](https://huggingface.co/google/siglip2-base-patch16-224)