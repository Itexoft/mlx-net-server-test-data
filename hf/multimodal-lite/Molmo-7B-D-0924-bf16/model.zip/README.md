---
license: apache-2.0
language:
- en
base_model:
- openai/clip-vit-large-patch14-336
- Qwen/Qwen2-7B
pipeline_tag: image-text-to-text
tags:
- multimodal
- olmo
- molmo
- pixmo
- mlx
library_name: transformers
---

# mlx-community/Molmo-7B-D-0924-bf16
This model was converted to MLX format from [`allenai/Molmo-7B-D-0924`]() using mlx-vlm version **0.1.9**.
Refer to the [original model card](https://huggingface.co/allenai/Molmo-7B-D-0924) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/Molmo-7B-D-0924-bf16 --max-tokens 100 --temp 0.0
```
