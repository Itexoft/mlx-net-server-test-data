---
datasets:
- liuhaotian/LLaVA-Instruct-150K
language:
- en
license: llama2
pipeline_tag: image-text-to-text
tags:
- vision
- image-text-to-text
- mlx
inference: false
arxiv: 2304.08485
---

# mlx-community/llava-1.5-7b-4bit
This model was converted to MLX format from [`llava-hf/llava-1.5-7b-hf`]() using mlx-vlm version **0.1.0**.
Refer to the [original model card](https://huggingface.co/llava-hf/llava-1.5-7b-hf) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/llava-1.5-7b-4bit --max-tokens 100 --temp 0.0
```
