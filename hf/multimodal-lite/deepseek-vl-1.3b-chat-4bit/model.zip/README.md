---
license: other
tags:
- mlx
license_name: deepseek
license_link: LICENSE
pipeline_tag: image-text-to-text
---

# mlx-community/deepseek-vl-1.3b-4bit
This model was converted to MLX format from [`deepseek-ai/deepseek-vl-1.3b-chat`]() using mlx-vlm version **0.0.8**.
Refer to the [original model card](https://huggingface.co/deepseek-ai/deepseek-vl-1.3b-chat) for more details on the model.
## Use with mlx

```bash
pip install -U mlx-vlm
```

```bash
python -m mlx_vlm.generate --model mlx-community/deepseek-vl-1.3b-4bit --max-tokens 100 --temp 0.0
```
